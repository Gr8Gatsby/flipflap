var game = {
	animating: false,
	gameGrid: null,
	direction: null,
	isOver: false
}